united_kingdom = [
  {
    name: "Scotland",
    population: 5295000,
    capital: "Edinburgh"
  },
  {
    name: "Wales",
    population: 3063000,
    capital: "Swansea"
  },
  {
    name: "England",
    population: 53010000,
    capital: "London"
  }
]

# capital_change = united_kingdon ["Erik"][:home_town]
# town_change.delete("Linlithgow")
# town_change.push("Edinburgh")
# p users ["Erik"][:home_town]


# meals = Hash.new(0)
#1
united_kingdom[1][:capital] = "Cardiff"
#2
united_kingdom.push(:name=>"Northern Ireland", :population=>"1,811,000)", :capital=> "Belfast")
#3
# for every in united_kingdom
#   p "#{united_kingdom[0..3][:name]}".values
# end
#
#4
total_population = 0

for each_population in united_kingdom
total_population += each_population[:population.values]
end
p total_population


p united_kingdom


# 1. Change the capital of Wales from `"Swansea"` to `"Cardiff"`.
# 2. Create a Hash for Northern Ireland and add it to the `united_kingdom` array (The capital is Belfast, and the population is 1,811,000).
# 3. Use a loop to print the names of all the countries in the UK.
# 4. Use a loop to find the total population of the UK.
